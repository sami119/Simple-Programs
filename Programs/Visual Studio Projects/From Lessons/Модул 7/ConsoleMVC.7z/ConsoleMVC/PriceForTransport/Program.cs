﻿using System;
using PriceForTransport.Controllers;

namespace PriceForTransport
{
    class Program
    {
        static void Main(string[] args)
        {
            PriceForTransportController priceForTransport = new PriceForTransportController();
            Console.ReadKey();
        }
    }
}
