﻿public abstract class Shape
{
    public double Perimeter { get; set; }

    public double Area { get; set; }

    public Shape()
    {
        this.Perimeter = this.CalculatePerimeter();
        this.Area = this.CalculateArea();
    }

    public abstract double CalculatePerimeter();

    public abstract double CalculateArea();

    public virtual string Draw()
    {
        return "Drawing ";
    }
}
