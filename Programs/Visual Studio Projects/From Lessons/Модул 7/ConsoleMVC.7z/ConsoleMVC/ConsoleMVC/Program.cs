﻿using System;
using ConsoleMVC.Controllers;

namespace ConsoleMVC
{
    class Program
    {
        static void Main(string[] args)
        {
            TipCalculatorController tipCalculatorController = new TipCalculatorController();
            Console.ReadKey();
        }
    }
}
